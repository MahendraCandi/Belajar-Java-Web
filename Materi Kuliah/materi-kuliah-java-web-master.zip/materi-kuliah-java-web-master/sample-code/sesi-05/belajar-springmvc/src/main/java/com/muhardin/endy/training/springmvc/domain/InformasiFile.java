package com.muhardin.endy.training.springmvc.domain;

public class InformasiFile {
    private String nama;
    private Long ukuran;

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public Long getUkuran() {
        return ukuran;
    }

    public void setUkuran(Long ukuran) {
        this.ukuran = ukuran;
    }

    
}
