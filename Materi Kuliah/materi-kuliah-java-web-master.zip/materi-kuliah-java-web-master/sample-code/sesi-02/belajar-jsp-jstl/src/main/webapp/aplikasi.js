HaloController = function($scope){
	$scope.email = "endy@artivisi.com"

	$scope.socialNetwork = [
		"Facebook",
		"Twitter",
		"Google+"
	];
}