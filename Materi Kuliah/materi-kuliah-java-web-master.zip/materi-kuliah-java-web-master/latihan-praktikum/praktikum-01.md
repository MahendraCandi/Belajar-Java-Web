# Praktikum 1 #

* Waktu : 200 menit

1. Buatlah project java web dengan Maven. Buatkan file coba.html dengan isi sesuka Anda. File ini nantinya harus bisa diakses melalui browser. Simpan seluruh source code di github

2. Jalankan project yang telah dibuat melalui command prompt. 
Copy-paste output di command prompt dan simpan di text file bernama output-npm.txt
Ganti npm dengan NPM Anda.

3. Akses aplikasi web yang sudah dijalankan melalui browser. Ambil screenshotnya dan simpan dengan nama screenshot-halo-npm.jpg
Ganti npm dengan NPM Anda.

4. Buatlah servlet yang menerima parameter nama dan mengeluarkan tulisan Halo NAMA. Input dikonversi dulu menjadi huruf besar sebelum ditampilkan. Contoh:

        * input : endy
        * output : Halo ENDY

5. Deploy aplikasi yang sudah dibuat ke Tomcat, lalu akses dari browser. Copy log filenya dan buat screenshot seperti no.3

6. Undeploy aplikasi dari Tomcat. Copy log filenya dan buat screenshot seperti no.3

7. Buat penjelasan singkat untuk langkah-langkah yang dilakukan dalam praktikum ini dalam file doc. 
Masukkan log dan screenshot ke dalam penjelasan tersebut.
File diberi nama laporan-praktikum-npm.doc dan dikumpulkan ke asisten melalui email.
